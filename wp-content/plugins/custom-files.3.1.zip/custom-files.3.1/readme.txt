** DO NOT UPLOAD TO YOUR PLUGINS FOLDER **

Version 1.1

These files need to be uploaded to the "/wp-content/uploads/espresso/" directory on your server after the main plugin (Event Espresso) has been successfully installed. 

Be sure to look in each of the custom files for examples.

Custom files upload path example:
/wp-content/uploads/espresso/custom_functions.php
/wp-content/uploads/espresso/custom_includes.php
/wp-content/uploads/espresso/custom_shortcodes.php

Templates upload path example:
/wp-content/uploads/espresso/templates/date_range_display.php
/wp-content/uploads/espresso/templates/table_display.php

Usage example:
custom_includes.php - Should be used to include your custom templates or any other files you need loaded into the plugin.
custom_functions.php - Place all of your custom functions in this file.
custom_shortcodes.php - Place all of your custom shortcodes in this file.

** DO NOT UPLOAD TO YOUR PLUGINS FOLDER **