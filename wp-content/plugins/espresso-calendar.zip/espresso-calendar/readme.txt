This plugin/addon needs to be uploaded to the "/wp-content/plugins/" directory on your server or installed using the WordPress plugins installer.

Once the plugin/addon is installed and activated just paste the shortcode [ESPRESSO_CALENDAR] into a page of your website to display a calendar on that page.
